# ChiroCandy Design System

The brand and UI system for **ChiroCandy Marketing** — the premium growth partner for chiropractic and healthcare offices. ChiroCandy helps chiropractors build trust, become known, and get found through one integrated system: ads, SEO/AEO, websites, CTV, reactivation, and AI follow-up.

**Brand feel:** enterprise-level credibility, founder-led trust, modern AI-powered marketing. Dark navy-first with green accents. Confident, direct, premium. Never cute, never generic agency, never hypey.

**Core message:** Build Trust. Become Known. Get Found.

---

## Sources

This system was built from ChiroCandy-provided materials (read-only at build time):

- `chirocandy-design-source/ChiroCandy-Design-System.md` — the approved brand/design spec (July 2026), source of truth for color, type, motion, voice.
- `chirocandy-design-source/ChiroCandy-Homepage-Final Design.html` — the approved homepage direction; exact token values, component styles, and copy were lifted from here.
- Uploaded logos: `New ChiroCandy Logo White.png`, `New ChiroCandy Logo Navy.png`, `chirocandy chat logo (350x350).png` (mascot mark). Copied into `assets/`.

**Font note:** the brand uses **Space Grotesk** (display) and **Inter** (body), loaded from Google Fonts to match the approved homepage. These are the real brand fonts, not substitutions. Legacy ChiroCandy materials used Montserrat/Poppins; new work uses Space Grotesk.

---

## Index / manifest

- `styles.css` — global entry point (consumers link this one file). `@import`s the tokens + fonts below.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`.
- `assets/` — `logo-white.png`, `logo-navy.png`, `logo-mark.png`.
- `components/` — reusable React primitives (see below).
- `ui_kits/website/` — full interactive homepage recreation.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `SKILL.md` — Agent-Skills-compatible entry for downloading/using this system.

### Components

Grouped React primitives, all styled via CSS custom properties. Import from the compiled namespace.

- **Button** (`components/actions/`) — primary green-gradient CTA and glass ghost variants, with nudging arrow.
- **Eyebrow** (`components/badges/`) — uppercase green section label; optional hero pill with pulsing dot.
- **IconChip** (`components/badges/`) — rounded-square mint chip for short service labels (ADS, SEO, WEB, CTV, RE, AI) or glyphs.
- **CredPill** (`components/badges/`) — outlined credential pill with green lead-in.
- **Card** (`components/cards/`) — glassmorphic panel with optional cursor-following green glow and lift.
- **StatBlock** (`components/cards/`) — big Space Grotesk stat with green accent characters.
- **TestimonialCard** (`components/cards/`) — navy glass quote card with one green-highlighted phrase and author row.
- **Marquee** (`components/marquee/`) — continuous proof strip, pauses on hover.

### UI kits

- **Website** (`ui_kits/website/`) — the full ChiroCandy marketing homepage: signal-field hero, proof marquee, problem grid, the interconnected "system engine," proof/results, a live AI-follow-up chat demo, founder section, and final CTA with a working booking modal. See `ui_kits/website/README.md`.

---

## Content fundamentals

How ChiroCandy writes. Follow this for all on-canvas copy.

- **Voice:** confident, direct, spartan, strategic, calm. Proof over promises. Short sentences. No hype words, no exclamation stacking.
- **Person:** speaks to the chiropractor as "you"/"your practice"; ChiroCandy is "we"/"the system." Founder-led ("Built by Billy Sticker").
- **Casing:** sentence case for headlines and body. Eyebrows are UPPERCASE with wide tracking. Never all-caps headlines.
- **Headlines** are sentence-fragment confident: "Proof, not promises." / "One engine. Every channel working together." / "Build Trust. Become Known. Get Found."
- **Proof language is numbers-first:** "2,000+ offices served since 2015," "$450M+ estimated client revenue generated," "11 years chiropractic only." Numbers carry the argument.
- **Framing:** chiropractors need to be known, found, and trusted. Diagnosis before prescription (Day One / Day Two language in sales contexts). Problems are named plainly ("random acts of hope") before the system is offered.
- **Emoji:** none. Not part of the brand.
- **Punctuation rule (hard):** never use em dashes. Use periods, commas, or colons instead.
- **Highlight discipline:** exactly one shimmer-gradient word/phrase per page (the "Get Found." treatment); one green-highlighted phrase per testimonial.
- **Primary CTA is always:** "Book a Strategy Call." Secondary: "See What's Working."

---

## Visual foundations

- **Color mood:** dark-navy-first. `#04101F` near-black navy is the default canvas. White/fog is reserved for documents and long-form reading. Green (`#7ED957`) is an accent — roughly 10% of any layout, marking CTAs, key numbers, and the single most important element. If everything is green, nothing is. Never pure black or pure gray backgrounds. Red only for problem framing, always desaturated (`#E88` on `rgba(226,90,90,.12)`).
- **Type:** Space Grotesk for display (600–700, tracking −0.02em, tight leading 1.03–1.16); Inter for body/UI (400–600, line-height 1.6). Hero clamps to 5.6rem; eyebrows are 0.76rem uppercase green with 0.22em tracking; stats are Space Grotesk 700 ~2.6rem, white with green accent characters.
- **Layout:** max content width 1180px, 28px side padding. Section rhythm 120px desktop / 80px mobile. Cards in 3–4 columns desktop, 2 tablet, 1 mobile. Generous negative space — density is the enemy of premium.
- **Backgrounds:** dark navy fields, often with a large soft radial glow (navy or green). The signature motif is the **"signal field"**: a living particle surface (circular dot grid, rippling sine waves, slow rotation, color flowing between navy and green, edge-faded, additive glow) behind the hero and final CTA. No stock photography; imagery is real and founder-led with a navy-friendly grade and soft green rim.
- **Corners:** cards 20–24px, buttons 14px, inputs 11px, chips 10px, pills/badges 999px.
- **Cards:** glassmorphism — panel fill (`rgba(12,38,71,.55)`) + 1px line border + backdrop-blur(10px). Reserved for dark surfaces. Interactive cards get a green border glow that follows the cursor (radial-gradient mask) plus a `translateY(-6px)` lift on hover.
- **Shadows:** large, soft, and often colored. Hero objects: `0 40px 100px rgba(0,0,0,.6)`. Green CTAs: `0 10px 34px rgba(126,217,87,.35)`, deepening on hover.
- **Borders/dividers:** hairline `rgba(150,171,198,.14)`. Accent borders use green at 22–60% opacity.
- **Transparency & blur:** used deliberately for depth — frosted nav (blur 18px after 40px scroll), glass cards (blur 10px), glass badges (blur 6px). Never gratuitous.
- **Motion:** motion is the design, not decoration. Everything eases with `cubic-bezier(0.2,0.8,0.2,1)`. **Nothing bounces.** Headlines rise word-by-word (34–38px travel, 0.15s stagger); sections fade+rise 44px staggered 0.1s; counters count up 1.6s ease-out on first view; the hero shimmer sweeps once every 5s on a single phrase; a soft green-navy cursor aura follows the pointer on desktop (screen blend). Always honor `prefers-reduced-motion` with a static, fully-assembled fallback.
- **Hover states:** ghost buttons brighten border + turn text green; nav links grow a green underline and go white; cards lift and reveal a green glow; cred pills brighten border + text. **Press:** primary buttons deepen their green shadow (no shrink).

---

## Iconography

- **Approach:** minimal, geometric, line-based. ChiroCandy's signature icon substitute is the **IconChip** — a rounded-square mint chip holding a short service label (ADS, SEO, WEB, CTV, RE, AI) or a single glyph (✓ for wins, ✕ for problems). Short-word labels are on-brand and preferred over pictograms.
- **No built-in icon font or SVG icon set** ships in the source. The homepage uses only Unicode glyphs (✓, ✕, ●, →) inside chips, dots, and buttons — no icon library. This system follows suit: use the provided glyphs and IconChip labels rather than importing an icon pack. If a future surface genuinely needs pictographic icons, add a CDN set with a matching thin geometric stroke (e.g. Lucide) and document it here — do not hand-draw SVGs.
- **Emoji:** never used.
- **Logo mascot** (headphone robot) appears only inside the logo lockup, never as a standalone spot illustration.

---

## Logo usage

- White logo on dark backgrounds (primary). Navy logo on white/fog. Never on mid-tone backgrounds with poor contrast.
- Clear space: half the mascot height on all sides. Minimum height 26px digital.
- Never recolor, stretch, or reconstruct the mark.

---

## Intentional additions

- **CredPill** and **IconChip** are named primitives extracted from the homepage's inline credential pills and mint service chips — the source uses them as recurring patterns, so they are formalized as components rather than invented.
- The website UI kit's **booking modal** is a small interactive affordance added to make the "Book a Strategy Call" CTA demonstrable; it uses only existing components (Card, Button, Eyebrow, IconChip).
