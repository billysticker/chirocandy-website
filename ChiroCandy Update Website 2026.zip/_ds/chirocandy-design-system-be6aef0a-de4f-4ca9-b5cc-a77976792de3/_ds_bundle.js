/* @ds-bundle: {"format":4,"namespace":"ChiroCandyDesignSystem_be6aef","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"CredPill","sourcePath":"components/badges/CredPill.jsx"},{"name":"Eyebrow","sourcePath":"components/badges/Eyebrow.jsx"},{"name":"IconChip","sourcePath":"components/badges/IconChip.jsx"},{"name":"Card","sourcePath":"components/cards/Card.jsx"},{"name":"StatBlock","sourcePath":"components/cards/StatBlock.jsx"},{"name":"TestimonialCard","sourcePath":"components/cards/TestimonialCard.jsx"},{"name":"Marquee","sourcePath":"components/marquee/Marquee.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"3c281d06fe3f","components/badges/CredPill.jsx":"a02de1895914","components/badges/Eyebrow.jsx":"ada549ae5996","components/badges/IconChip.jsx":"2076931150e1","components/cards/Card.jsx":"a60fe029c973","components/cards/StatBlock.jsx":"ffda385e5ed4","components/cards/TestimonialCard.jsx":"72621d518585","components/marquee/Marquee.jsx":"5beaf43a895e","ui_kits/website/EndSections.jsx":"4eac52e42b60","ui_kits/website/HeroSection.jsx":"8d4dd50dffba","ui_kits/website/MidSections.jsx":"d4e61b726fa2","ui_kits/website/SiteChrome.jsx":"e090ba45f6cd"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ChiroCandyDesignSystem_be6aef = window.ChiroCandyDesignSystem_be6aef || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ChiroCandy primary action button.
 * Variants: "green" (primary gradient fill) and "ghost" (transparent, glass border).
 * Includes an optional arrow glyph that nudges right on hover.
 */
function Button({
  children,
  variant = 'green',
  size = 'md',
  arrow = false,
  href,
  onClick,
  disabled = false,
  style = {},
  ...rest
}) {
  const base = {
    position: 'relative',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '0.55rem',
    fontFamily: "var(--font-body, 'Inter', sans-serif)",
    fontWeight: 600,
    borderRadius: 'var(--cc-radius-btn, 14px)',
    border: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    lineHeight: 1,
    transition: 'box-shadow .25s var(--cc-ease), border-color .25s var(--cc-ease), color .25s var(--cc-ease), transform .15s var(--cc-ease)',
    opacity: disabled ? 0.5 : 1,
    whiteSpace: 'nowrap'
  };
  const sizes = {
    sm: {
      fontSize: '0.86rem',
      padding: '0.68rem 1.3rem'
    },
    md: {
      fontSize: '0.96rem',
      padding: '1rem 1.9rem'
    },
    lg: {
      fontSize: '1.05rem',
      padding: '1.1rem 2.2rem'
    }
  };
  const variants = {
    green: {
      background: 'var(--cc-grad-cta, linear-gradient(135deg,#9BF07A,#5CBF3E))',
      color: '#04230F',
      boxShadow: disabled ? 'none' : 'var(--cc-shadow-cta, 0 10px 34px rgba(126,217,87,.35))'
    },
    ghost: {
      background: 'rgba(255,255,255,0.03)',
      border: '1px solid var(--cc-line, rgba(150,171,198,.14))',
      backdropFilter: 'blur(8px)',
      color: 'var(--cc-ink, #EAF1FA)'
    }
  };
  const styles = {
    ...base,
    ...sizes[size],
    ...variants[variant],
    ...style
  };
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, children, arrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      transition: 'transform .2s var(--cc-ease)',
      display: 'inline-block'
    },
    className: "cc-btn-arrow"
  }, "\u2192"));
  const hoverHandlers = disabled ? {} : {
    onMouseEnter: e => {
      const el = e.currentTarget;
      if (variant === 'green') el.style.boxShadow = 'var(--cc-shadow-cta-h, 0 16px 48px rgba(126,217,87,.55))';else {
        el.style.borderColor = 'rgba(126,217,87,0.6)';
        el.style.color = 'var(--cc-green, #7ED957)';
      }
      const arr = el.querySelector('.cc-btn-arrow');
      if (arr) arr.style.transform = 'translateX(4px)';
    },
    onMouseLeave: e => {
      const el = e.currentTarget;
      if (variant === 'green') el.style.boxShadow = variants.green.boxShadow;else {
        el.style.borderColor = 'var(--cc-line, rgba(150,171,198,.14))';
        el.style.color = 'var(--cc-ink, #EAF1FA)';
      }
      const arr = el.querySelector('.cc-btn-arrow');
      if (arr) arr.style.transform = 'translateX(0)';
    }
  };
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href,
      style: styles
    }, hoverHandlers, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    style: styles,
    onClick: disabled ? undefined : onClick,
    disabled: disabled
  }, hoverHandlers, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/badges/CredPill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * CredPill — outlined pill for credentials / proof points. Optional green lead-in via `label`.
 * Border brightens to green on hover.
 */
function CredPill({
  children,
  label,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'baseline',
      gap: '0.4rem',
      border: '1px solid var(--cc-line, rgba(150,171,198,.14))',
      borderRadius: 'var(--cc-radius-pill, 999px)',
      padding: '0.55rem 1.15rem',
      fontFamily: "var(--font-body, 'Inter', sans-serif)",
      fontSize: '0.82rem',
      color: 'var(--cc-muted, #96ABC6)',
      transition: 'border-color .2s var(--cc-ease), color .2s var(--cc-ease)',
      cursor: 'default',
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = 'var(--cc-green, #7ED957)';
      e.currentTarget.style.color = 'var(--cc-ink, #EAF1FA)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = 'var(--cc-line, rgba(150,171,198,.14))';
      e.currentTarget.style.color = 'var(--cc-muted, #96ABC6)';
    }
  }, rest), label && /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--cc-green, #7ED957)',
      fontWeight: 700
    }
  }, label), label && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      color: 'var(--cc-muted-2)'
    }
  }, "\xB7"), children);
}
Object.assign(__ds_scope, { CredPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/badges/CredPill.jsx", error: String((e && e.message) || e) }); }

// components/badges/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Eyebrow label — the small uppercase green tracking label that opens every major section.
 * Set `badge` to wrap it in a pill with a pulsing green dot (hero-style).
 */
function Eyebrow({
  children,
  badge = false,
  style = {},
  ...rest
}) {
  const label = {
    fontFamily: "var(--font-body, 'Inter', sans-serif)",
    fontSize: 'var(--cc-text-eyebrow, 0.76rem)',
    fontWeight: 600,
    letterSpacing: 'var(--cc-track-eyebrow, 0.22em)',
    textTransform: 'uppercase',
    color: 'var(--cc-green, #7ED957)'
  };
  if (!badge) return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...label,
      ...style
    }
  }, rest), children);
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...label,
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.6rem',
      border: '1px solid var(--border-accent, rgba(126,217,87,0.3))',
      background: 'rgba(126,217,87,0.06)',
      padding: '0.5rem 1.1rem',
      borderRadius: 'var(--cc-radius-pill, 999px)',
      backdropFilter: 'blur(6px)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--cc-green, #7ED957)',
      boxShadow: '0 0 12px var(--cc-green, #7ED957)',
      flexShrink: 0
    }
  }), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/badges/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/badges/IconChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChip — rounded-square mint chip holding a short label (ADS, SEO, WEB, CTV, RE, AI)
 * or a single glyph. On-brand substitute for decorative icons.
 * tone: "mint" (green) or "alert" (desaturated red, for problem framing).
 */
function IconChip({
  children,
  tone = 'mint',
  size = 36,
  style = {},
  ...rest
}) {
  const tones = {
    mint: {
      background: 'var(--cc-green-mint, rgba(126,217,87,0.14))',
      color: 'var(--cc-green, #7ED957)'
    },
    alert: {
      background: 'var(--cc-alert-fill, rgba(226,90,90,0.12))',
      color: 'var(--cc-alert, #E88888)'
    },
    navy: {
      background: 'rgba(18,57,100,0.5)',
      color: 'var(--cc-ink, #EAF1FA)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      borderRadius: 'var(--cc-radius-chip, 10px)',
      fontFamily: "var(--font-heading, 'Space Grotesk', sans-serif)",
      fontWeight: 700,
      fontSize: size >= 44 ? '0.8rem' : '0.72rem',
      letterSpacing: '0.02em',
      flexShrink: 0,
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/badges/IconChip.jsx", error: String((e && e.message) || e) }); }

// components/cards/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — glass panel on dark surfaces. Set `glow` for the cursor-following green
 * border glow + lift on hover (used for the problem / feature grids).
 * `highlight` swaps the flat panel fill for the navy glass gradient.
 */
function Card({
  children,
  glow = false,
  highlight = false,
  style = {},
  ...rest
}) {
  const ref = React.useRef(null);
  const base = {
    position: 'relative',
    background: highlight ? 'var(--cc-grad-panel, linear-gradient(160deg,rgba(18,57,100,.6),rgba(7,28,54,.9)))' : 'var(--cc-panel, rgba(12,38,71,.55))',
    border: '1px solid var(--cc-line, rgba(150,171,198,.14))',
    borderRadius: 'var(--cc-radius-card, 22px)',
    padding: '1.8rem',
    backdropFilter: 'blur(var(--cc-blur-glass, 10px))',
    transition: 'transform .25s var(--cc-ease), border-color .25s var(--cc-ease)',
    overflow: 'hidden',
    color: 'var(--cc-ink, #EAF1FA)'
  };
  const onMove = e => {
    if (!glow || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    ref.current.style.setProperty('--mx', `${e.clientX - r.left}px`);
    ref.current.style.setProperty('--my', `${e.clientY - r.top}px`);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    ref: ref,
    style: {
      ...base,
      ...style
    },
    onMouseMove: onMove,
    onMouseEnter: e => {
      if (glow) e.currentTarget.style.transform = 'translateY(-6px)';
    },
    onMouseLeave: e => {
      if (glow) {
        e.currentTarget.style.transform = 'none';
        const g = e.currentTarget.querySelector('.cc-card-glow');
        if (g) g.style.opacity = '0';
      }
    },
    onMouseOver: e => {
      if (glow) {
        const g = e.currentTarget.querySelector('.cc-card-glow');
        if (g) g.style.opacity = '1';
      }
    }
  }, rest), glow && /*#__PURE__*/React.createElement("span", {
    className: "cc-card-glow",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: -1,
      borderRadius: 'var(--cc-radius-card, 22px)',
      padding: 1,
      background: 'radial-gradient(220px circle at var(--mx,50%) var(--my,50%), rgba(126,217,87,.7), transparent 45%)',
      WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
      WebkitMaskComposite: 'xor',
      maskComposite: 'exclude',
      opacity: 0,
      transition: 'opacity .3s var(--cc-ease)',
      pointerEvents: 'none'
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/Card.jsx", error: String((e && e.message) || e) }); }

// components/cards/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * StatBlock — a big Space Grotesk number with a muted label.
 * Use `prefix`/`suffix` (e.g. "$", "+", "M", "yrs", "x") for the green accent characters.
 * The main `value` renders white; accents render green.
 */
function StatBlock({
  value,
  prefix,
  suffix,
  label,
  align = 'center',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--cc-panel, rgba(12,38,71,.55))',
      border: '1px solid var(--cc-line, rgba(150,171,198,.14))',
      borderRadius: 'var(--cc-radius-card, 20px)',
      padding: '2.1rem 1.6rem',
      textAlign: align,
      backdropFilter: 'blur(var(--cc-blur-glass, 10px))',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-heading, 'Space Grotesk', sans-serif)",
      fontSize: 'var(--cc-text-stat, 2.6rem)',
      fontWeight: 700,
      color: '#fff',
      lineHeight: 1.05,
      letterSpacing: '-0.02em'
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cc-green, #7ED957)'
    }
  }, prefix), value, suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cc-green, #7ED957)'
    }
  }, suffix)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.84rem',
      color: 'var(--cc-muted, #96ABC6)',
      marginTop: '0.3rem'
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/cards/TestimonialCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TestimonialCard — navy glass gradient panel with a Space Grotesk quote,
 * one green-highlighted phrase, and an author row (avatar + name + practice + city).
 * Pass `highlight` text to color a phrase green inside the quote, or use the
 * `<TestimonialCard.HL>` helper by wrapping phrases yourself in `quote`.
 */
function TestimonialCard({
  quote,
  name,
  practice,
  city,
  initials = 'DR',
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--cc-grad-panel, linear-gradient(160deg,rgba(18,57,100,.6),rgba(7,28,54,.9)))',
      border: '1px solid var(--cc-line, rgba(150,171,198,.14))',
      borderRadius: 'var(--cc-radius-card, 22px)',
      padding: '2.6rem',
      backdropFilter: 'blur(12px)',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      gap: '2rem',
      color: 'var(--cc-ink, #EAF1FA)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontFamily: "var(--font-heading, 'Space Grotesk', sans-serif)",
      fontSize: '1.45rem',
      lineHeight: 1.45,
      fontWeight: 500
    }
  }, quote), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '1rem'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 50,
      height: 50,
      borderRadius: '50%',
      background: 'linear-gradient(135deg, var(--cc-navy, #123964), var(--cc-green, #7ED957))',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '0.7rem',
      fontWeight: 700,
      color: '#04230F',
      flexShrink: 0
    }
  }, initials), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", {
    style: {
      display: 'block',
      fontSize: '0.94rem'
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.8rem',
      color: 'var(--cc-muted, #96ABC6)'
    }
  }, practice, practice && city ? ' · ' : '', city))));
}

/** Green-highlight a phrase inside a quote. */
TestimonialCard.HL = function HL({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cc-green, #7ED957)'
    }
  }, children);
};
Object.assign(__ds_scope, { TestimonialCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/TestimonialCard.jsx", error: String((e && e.message) || e) }); }

// components/marquee/Marquee.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Marquee — continuous horizontal proof strip. Pass `items` (array of nodes) or children.
 * Green-highlight numbers by wrapping them in <b>. Pauses on hover.
 */
function Marquee({
  items,
  children,
  speed = 30,
  style = {},
  ...rest
}) {
  const content = items ? items.map((it, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: 'inline-flex',
      gap: '0.4rem'
    }
  }, it)) : children;

  // duplicate the run so the loop is seamless
  const run = /*#__PURE__*/React.createElement("div", {
    className: "cc-marquee-track",
    style: {
      display: 'flex',
      gap: '4.5rem',
      width: 'max-content',
      fontFamily: "var(--font-heading, 'Space Grotesk', sans-serif)",
      fontSize: '1rem',
      color: 'var(--cc-muted, #96ABC6)',
      whiteSpace: 'nowrap',
      animation: `cc-marquee-scroll ${speed}s linear infinite`
    }
  }, content, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: 'flex',
      gap: '4.5rem'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: e => {
      const t = e.currentTarget.querySelector('.cc-marquee-track');
      if (t) t.style.animationPlayState = 'paused';
    },
    onMouseLeave: e => {
      const t = e.currentTarget.querySelector('.cc-marquee-track');
      if (t) t.style.animationPlayState = 'running';
    },
    style: {
      borderTop: '1px solid var(--cc-line, rgba(150,171,198,.14))',
      borderBottom: '1px solid var(--cc-line, rgba(150,171,198,.14))',
      background: 'rgba(7,28,54,0.6)',
      backdropFilter: 'blur(var(--cc-blur-glass, 10px))',
      overflow: 'hidden',
      padding: '1.35rem 0',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("style", null, `@keyframes cc-marquee-scroll { to { transform: translateX(-50%); } }
        @media (prefers-reduced-motion: reduce){ .cc-marquee-track{ animation:none !important; } }
        .cc-marquee-track b { color: var(--cc-green, #7ED957); }`), run);
}
Object.assign(__ds_scope, { Marquee });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marquee/Marquee.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/EndSections.jsx
try { (() => {
/* ChiroCandy AI demo, founder, and final CTA sections. */

function AIDemoSection() {
  const [msgs, setMsgs] = React.useState([]);
  const [city, setCity] = React.useState('');
  const [running, setRunning] = React.useState(false);
  function run() {
    const place = city.trim() || 'your city';
    if (running) return;
    setRunning(true);
    const script = [{
      who: 'them',
      text: `Hi, do you take new patients in ${place}? My lower back has been killing me.`
    }, {
      who: 'sys',
      text: 'AI responded in 8 seconds'
    }, {
      who: 'ai',
      text: `Hi! Yes, we're welcoming new patients in ${place}. Sorry to hear about your back. I can get you in as early as tomorrow morning. What works better, 9:00 AM or 2:30 PM?`
    }, {
      who: 'them',
      text: '9 AM works.'
    }, {
      who: 'ai',
      text: `Booked. You're confirmed for 9:00 AM. I'll text a reminder and new-patient forms so your first visit is quick. See you soon!`
    }, {
      who: 'sys',
      text: 'Appointment booked · front desk notified'
    }];
    setMsgs([]);
    script.forEach((m, i) => setTimeout(() => {
      setMsgs(prev => [...prev, m]);
      if (i === script.length - 1) setRunning(false);
    }, 700 * (i + 1)));
  }
  const bub = {
    them: {
      background: 'rgba(150,171,198,.12)',
      border: '1px solid var(--cc-line)',
      alignSelf: 'flex-start',
      borderBottomLeftRadius: 4
    },
    ai: {
      background: 'rgba(126,217,87,.13)',
      border: '1px solid rgba(126,217,87,.3)',
      alignSelf: 'flex-end',
      borderBottomRightRadius: 4
    },
    sys: {
      alignSelf: 'center',
      background: 'none',
      border: '1px dashed rgba(126,217,87,.4)',
      color: 'var(--cc-green)',
      fontSize: '.78rem',
      textAlign: 'center'
    }
  };
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '120px 0'
    }
  }, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.05fr',
      gap: '4rem',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cc-ai-copy"
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    badge: true
  }, "AI, Applied Practically"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: 'var(--cc-text-h2-sm)',
      fontWeight: 700,
      letterSpacing: '-.02em',
      color: '#fff',
      margin: '.8rem 0 1rem'
    }
  }, "Don't take our word for it. Run the demo."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--cc-muted)',
      lineHeight: 1.6
    }
  }, "This is what happens the moment a new patient reaches out to a ChiroCandy-powered practice. Type your city and watch the AI handle the lead in real time."), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: '1.6rem 0 0',
      padding: 0
    }
  }, ['Every lead answered in under 60 seconds, 24/7', 'Found when patients ask AI for "the best chiropractor near me"', 'Follow-up that books while your front desk sleeps'].map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    style: {
      display: 'flex',
      gap: '.9rem',
      marginBottom: '1.15rem',
      color: 'var(--cc-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cc-green)',
      fontWeight: 700
    }
  }, "\u2713"), t)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#030B16',
      border: '1px solid var(--cc-line)',
      borderRadius: 24,
      overflow: 'hidden',
      boxShadow: 'var(--cc-shadow-hero)',
      maxWidth: 460,
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '.8rem',
      padding: '1rem 1.3rem',
      borderBottom: '1px solid var(--cc-line)'
    }
  }, /*#__PURE__*/React.createElement(IconChip, {
    tone: "navy",
    size: 34,
    style: {
      borderRadius: '50%',
      background: 'linear-gradient(135deg,var(--cc-navy),var(--cc-green-deep))',
      color: '#04230F'
    }
  }, "AI"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: '.88rem',
      display: 'block',
      color: '#fff'
    }
  }, "Your Practice AI"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.72rem',
      color: 'var(--cc-green)',
      display: 'flex',
      alignItems: 'center',
      gap: '.35rem'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--cc-green)',
      boxShadow: '0 0 8px var(--cc-green)'
    }
  }), "Responds in seconds"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '1.2rem',
      minHeight: 330,
      display: 'flex',
      flexDirection: 'column',
      gap: '.7rem'
    }
  }, msgs.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'auto',
      color: 'var(--cc-muted-2)',
      fontSize: '.85rem',
      textAlign: 'center'
    }
  }, "Type your city and run the demo."), msgs.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      maxWidth: m.who === 'sys' ? '100%' : '82%',
      padding: '.75rem 1rem',
      borderRadius: 16,
      fontSize: '.88rem',
      lineHeight: 1.5,
      color: 'var(--cc-ink)',
      ...bub[m.who]
    }
  }, m.text))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '.6rem',
      padding: '1rem 1.2rem',
      borderTop: '1px solid var(--cc-line)'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: city,
    onChange: e => setCity(e.target.value),
    placeholder: "Type your city...",
    maxLength: 40,
    onKeyDown: e => e.key === 'Enter' && run(),
    style: {
      flex: 1,
      background: 'rgba(150,171,198,.08)',
      border: '1px solid var(--cc-line)',
      borderRadius: 11,
      padding: '.75rem 1rem',
      color: 'var(--cc-ink)',
      fontSize: '.9rem',
      fontFamily: 'var(--cc-font-body)'
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "green",
    size: "sm",
    onClick: run
  }, "Run the demo")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      fontSize: '.74rem',
      color: 'var(--cc-muted-2)',
      padding: '0 1rem .9rem'
    }
  }, "Simulation. No data is sent anywhere.")))));
}
function FounderSection() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '120px 0'
    }
  }, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: 'grid',
      gridTemplateColumns: '.82fr 1.18fr',
      gap: '4rem',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    },
    className: "cc-founder-photo"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '4/5',
      borderRadius: 24,
      background: 'linear-gradient(160deg,#14375F,#081E3C)',
      border: '1px solid var(--cc-line)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--cc-muted)',
      fontSize: '.85rem',
      textAlign: 'center',
      padding: '1.4rem',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(420px 320px at 70% 18%, rgba(126,217,87,.16), transparent)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative'
    }
  }, "[ Photo: Billy Sticker on stage at Parker Seminars ]")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: -16,
      right: -16,
      background: 'rgba(4,16,31,.9)',
      border: '1px solid rgba(126,217,87,.4)',
      borderRadius: 16,
      padding: '.9rem 1.2rem',
      fontSize: '.78rem',
      backdropFilter: 'blur(8px)',
      boxShadow: 'var(--cc-shadow-float)',
      color: 'var(--cc-ink)'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      display: 'block',
      color: 'var(--cc-green)',
      fontFamily: 'var(--cc-font-display)'
    }
  }, "Author + Speaker"), "Governing the AI Machine")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Founder-Led Strategy"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: 'var(--cc-text-h2-sm)',
      fontWeight: 700,
      letterSpacing: '-.02em',
      color: '#fff',
      margin: '.8rem 0 1rem'
    }
  }, "Built by Billy Sticker. Trusted by chiropractors since 2015."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--cc-muted)',
      lineHeight: 1.6
    }
  }, "Eleven years in one profession. The strategy behind your growth comes from the founder who has served 2,000+ chiropractic offices, not a rotating cast of account managers."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '.8rem',
      flexWrap: 'wrap',
      marginTop: '1.8rem'
    }
  }, /*#__PURE__*/React.createElement(CredPill, {
    label: "Author"
  }, "Governing the AI Machine"), /*#__PURE__*/React.createElement(CredPill, {
    label: "Speaker"
  }, "Parker Seminars"), /*#__PURE__*/React.createElement(CredPill, {
    label: "Founder"
  }, "ChiroCandy, est. 2015")))));
}
function FinalCTA({
  onCta
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      textAlign: 'center',
      padding: '170px 0',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      opacity: .5
    }
  }, /*#__PURE__*/React.createElement(SignalField, null)), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(800px 500px at 50% 50%, transparent, rgba(4,16,31,.82) 76%)'
    }
  }), /*#__PURE__*/React.createElement(Wrap, {
    style: {
      position: 'relative',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: 'clamp(2.2rem,4.6vw,3.6rem)',
      fontWeight: 700,
      letterSpacing: '-.02em',
      lineHeight: 1.1,
      color: '#fff',
      maxWidth: '48rem',
      margin: '0 auto 1.3rem'
    }
  }, "Ready to become the ", /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'linear-gradient(100deg,#9BF07A 20%,#E8FFDC 40%,#7ED957 60%,#4CAF3C 80%)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent'
    }
  }, "most trusted"), " and best-known practice in your market?"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--cc-muted)',
      maxWidth: '34rem',
      margin: '0 auto 2.6rem',
      lineHeight: 1.6
    }
  }, "One call. A clear diagnosis of your marketing health and a personalized plan to grow."), /*#__PURE__*/React.createElement(Button, {
    variant: "green",
    arrow: true,
    onClick: onCta
  }, "Book a Strategy Call")));
}
Object.assign(window, {
  AIDemoSection,
  FounderSection,
  FinalCTA
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/EndSections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HeroSection.jsx
try { (() => {
/* ChiroCandy hero — the "signal field" motif. A lightweight canvas particle
   ring behind a confident headline, marquee proof strip below. */

function SignalField() {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    let raf,
      t = 0,
      w,
      h,
      pts = [];
    const dpr = Math.min(devicePixelRatio || 1, 2);
    function size() {
      w = c.clientWidth;
      h = c.clientHeight;
      c.width = w * dpr;
      c.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      pts = [];
      const R = Math.min(w, h) * 0.52,
        step = 20;
      for (let x = -R; x <= R; x += step) for (let y = -R; y <= R; y += step) if (Math.hypot(x, y) <= R) pts.push({
        x,
        y,
        d: Math.hypot(x, y)
      });
    }
    size();
    const ro = new ResizeObserver(size);
    ro.observe(c);
    function draw() {
      ctx.clearRect(0, 0, w, h);
      const cx = w / 2,
        cy = h * 0.52;
      for (const p of pts) {
        const wave = Math.sin(p.d * 0.045 - t * 1.4) + Math.sin((p.x + p.y) * 0.02 + t);
        const mix = (wave + 2) / 4; // 0..1
        const r = Math.round(41 + (125 - 41) * mix);
        const g = Math.round(97 + (217 - 97) * mix);
        const b = Math.round(184 + (87 - 184) * mix);
        const edge = 1 - p.d / (Math.min(w, h) * 0.52);
        ctx.globalAlpha = Math.max(0, 0.12 + mix * 0.5) * edge;
        ctx.fillStyle = `rgb(${r},${g},${b})`;
        const s = 1.2 + wave * 0.7;
        ctx.beginPath();
        ctx.arc(cx + p.x, cy + p.y - wave * 5, Math.max(0.4, s), 0, 6.283);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (!reduced) {
        t += 0.016;
        raf = requestAnimationFrame(draw);
      }
    }
    if (reduced) {
      t = 1;
      draw();
    } else draw();
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%'
    }
  });
}
function Hero({
  onCta
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      minHeight: '92vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement(SignalField, null), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(1100px 680px at 50% 60%, transparent 25%, rgba(4,16,31,.7) 80%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2,
      padding: '120px 28px 80px',
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    badge: true
  }, "The Growth Engine for Chiropractors"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: 'var(--cc-text-hero)',
      fontWeight: 700,
      lineHeight: 1.03,
      letterSpacing: '-.02em',
      color: '#fff',
      margin: '1.6rem auto .4rem',
      maxWidth: '18ch'
    }
  }, "Build Trust. Become Known.", ' ', /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'linear-gradient(100deg,#9BF07A 20%,#E8FFDC 40%,#7ED957 60%,#4CAF3C 80%)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent'
    }
  }, "Get Found.")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '1.6rem auto 2.6rem',
      fontSize: '1.16rem',
      color: 'var(--cc-muted)',
      maxWidth: '37rem',
      lineHeight: 1.6
    }
  }, "One integrated system: ads, SEO, websites, CTV, reactivation, and AI follow-up. Built for chiropractic offices, and nothing else."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '1rem',
      justifyContent: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "green",
    arrow: true,
    onClick: onCta
  }, "Book a Strategy Call"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "See What's Working"))));
}
function ProofMarquee() {
  return /*#__PURE__*/React.createElement(Marquee, {
    items: [/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("b", null, "2,000+"), " offices served since 2015"), /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("b", null, "$450M+"), " estimated client revenue"), /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("b", null, "11 years"), " chiropractic only"), /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("b", null, "6 channels"), " in one integrated system"), /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("b", null, "<60s"), " lead response, 24/7")]
  });
}
Object.assign(window, {
  Hero,
  ProofMarquee,
  SignalField
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HeroSection.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/MidSections.jsx
try { (() => {
/* ChiroCandy mid sections — problem grid, the system engine, proof, stats. */

function Wrap({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--cc-content-max)',
      margin: '0 auto',
      padding: '0 28px',
      ...style
    }
  }, children);
}
function SecHead({
  eyebrow,
  title,
  sub,
  center
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '46rem',
      marginBottom: '3.6rem',
      textAlign: center ? 'center' : 'left',
      marginLeft: center ? 'auto' : 0,
      marginRight: center ? 'auto' : 0
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: 'var(--cc-text-h2)',
      fontWeight: 700,
      letterSpacing: '-.02em',
      lineHeight: 1.12,
      color: '#fff',
      margin: '.8rem 0 1rem'
    }
  }, title), sub && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--cc-muted)',
      fontSize: '1.06rem',
      margin: 0
    }
  }, sub));
}
const PROBLEMS = [['Random tactics', 'Disconnected campaigns that never compound into real growth.'], ['Cheap leads', 'Names on a list that never become patients in your office.'], ['Weak websites', 'Sites that look fine, rank nowhere, and convert nothing.'], ['Generalist agencies', 'Teams learning chiropractic on your dime and your reputation.']];
function ProblemSection() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '120px 0'
    }
  }, /*#__PURE__*/React.createElement(Wrap, null, /*#__PURE__*/React.createElement(SecHead, {
    center: true,
    eyebrow: "The Problem",
    title: /*#__PURE__*/React.createElement(React.Fragment, null, "Most chiropractic marketing is", /*#__PURE__*/React.createElement("br", null), "random acts of hope")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '1.1rem'
    },
    className: "cc-grid4"
  }, PROBLEMS.map(([t, d]) => /*#__PURE__*/React.createElement(Card, {
    glow: true,
    key: t
  }, /*#__PURE__*/React.createElement(IconChip, {
    tone: "alert"
  }, "\u2715"), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: '1.04rem',
      margin: '1.1rem 0 .45rem',
      color: '#fff'
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '.89rem',
      color: 'var(--cc-muted)',
      margin: 0
    }
  }, d))))));
}
const CHANNELS = [['01', 'Ads', 'Meta and Google campaigns proven in chiro markets'], ['02', 'SEO / AEO', 'Found in Maps, local search, and AI answers'], ['03', 'Websites', 'Built to convert visitors into booked visits'], ['04', 'CTV', "Your face on your community's living room TVs"], ['05', 'Reactivation', 'Past patients brought back, personally'], ['06', 'AI Follow-Up', 'Every lead answered and booked, 24/7']];
const NODES = [['Ads', '10%', '50%'], ['SEO / AEO', '30%', '85%'], ['Websites', '70%', '85%'], ['CTV', '90%', '50%'], ['Reactivation', '70%', '15%'], ['AI Follow-Up', '30%', '15%']];
function EngineSection() {
  const [active, setActive] = React.useState(5);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '120px 0',
      position: 'relative',
      background: 'radial-gradient(1000px 620px at 70% 50%, rgba(18,57,100,.5), transparent 62%)'
    }
  }, /*#__PURE__*/React.createElement(Wrap, {
    style: {
      display: 'grid',
      gridTemplateColumns: '.9fr 1.1fr',
      gap: '3rem',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "cc-engine-copy"
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "The ChiroCandy System"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontSize: 'clamp(2rem,3.6vw,2.9rem)',
      fontWeight: 700,
      letterSpacing: '-.02em',
      lineHeight: 1.12,
      color: '#fff',
      margin: '.8rem 0 1.8rem'
    }
  }, "One engine.", /*#__PURE__*/React.createElement("br", null), "Every channel connected."), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      padding: 0,
      margin: 0
    }
  }, CHANNELS.map(([k, b, s], i) => /*#__PURE__*/React.createElement("li", {
    key: k,
    onMouseEnter: () => setActive(i),
    style: {
      display: 'flex',
      gap: '1.1rem',
      padding: '.95rem 1.2rem',
      borderRadius: 14,
      marginBottom: '.4rem',
      alignItems: 'baseline',
      cursor: 'default',
      background: active === i ? 'rgba(126,217,87,.07)' : 'transparent',
      transition: 'background .3s'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--cc-font-display)',
      fontWeight: 700,
      flexShrink: 0,
      color: active === i ? 'var(--cc-green)' : 'var(--cc-muted-2)',
      transition: 'color .3s'
    }
  }, k), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", {
    style: {
      display: 'block',
      fontSize: '1.02rem',
      color: active === i ? '#fff' : 'var(--cc-muted)',
      transition: 'color .3s'
    }
  }, b), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '.86rem',
      color: 'var(--cc-muted-2)'
    }
  }, s))))), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: '1.6rem',
      paddingLeft: '1.2rem',
      fontSize: '1.05rem',
      color: 'var(--cc-muted)'
    }
  }, "Each channel makes the others stronger. ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--cc-green)'
    }
  }, "The system outperforms the menu."))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '1/1',
      maxWidth: 520,
      margin: '0 auto',
      width: '100%'
    },
    className: "cc-ring"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      width: '52%',
      aspectRatio: '1/1',
      transform: 'translate(-50%,-50%)',
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(126,217,87,.28), transparent 65%)',
      opacity: .2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      width: '31%',
      aspectRatio: '1/1',
      transform: 'translate(-50%,-50%)',
      borderRadius: '50%',
      zIndex: 2,
      background: 'radial-gradient(circle at 35% 30%, #1A4A80, #081E3C)',
      border: '1px solid rgba(126,217,87,.45)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      fontFamily: 'var(--cc-font-display)',
      fontWeight: 600,
      fontSize: '.9rem',
      lineHeight: 1.35,
      padding: '1rem',
      color: '#fff'
    }
  }, "Your", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--cc-green)'
    }
  }, "Practice")), NODES.map(([label, top, left], i) => /*#__PURE__*/React.createElement("div", {
    key: label,
    onMouseEnter: () => setActive(i),
    style: {
      position: 'absolute',
      top,
      left,
      transform: 'translate(-50%,-50%)',
      zIndex: 3,
      background: 'rgba(6,20,40,.92)',
      borderRadius: 13,
      padding: '.6rem 1.05rem',
      fontSize: '.8rem',
      fontWeight: 600,
      color: 'var(--cc-ink)',
      backdropFilter: 'blur(6px)',
      whiteSpace: 'nowrap',
      border: '1px solid ' + (active === i ? 'rgba(126,217,87,.6)' : 'var(--cc-line)'),
      boxShadow: active === i ? '0 0 26px rgba(126,217,87,.25), 0 12px 30px rgba(0,0,0,.4)' : '0 12px 30px rgba(0,0,0,.4)',
      opacity: active === i ? 1 : .55,
      transition: 'all .3s'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cc-green)',
      marginRight: '.4rem'
    }
  }, "\u25CF"), label)))));
}
function ProofSection() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: '120px 0'
    }
  }, /*#__PURE__*/React.createElement(Wrap, null, /*#__PURE__*/React.createElement(SecHead, {
    eyebrow: "Results",
    title: "Proof, not promises"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.2fr .8fr',
      gap: '1.2rem'
    },
    className: "cc-proof"
  }, /*#__PURE__*/React.createElement(TestimonialCard, {
    quote: /*#__PURE__*/React.createElement(React.Fragment, null, "\"We went from invisible to ", /*#__PURE__*/React.createElement(TestimonialCard.HL, null, "the best-known practice in our town."), " New patients tell us they see us everywhere.\""),
    name: "Dr. [Client Name]",
    practice: "[Practice Name]",
    city: "[City, ST]",
    initials: "CN"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '1.2rem'
    }
  }, /*#__PURE__*/React.createElement(StatBlock, {
    align: "left",
    prefix: "$",
    value: "8.42",
    label: "Average cost per lead, Meta campaigns",
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      border: '1px solid rgba(126,217,87,.22)'
    }
  }), /*#__PURE__*/React.createElement(StatBlock, {
    align: "left",
    value: "120",
    suffix: "+",
    label: "Leads in 30 days, single location",
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      border: '1px solid rgba(126,217,87,.22)'
    }
  }), /*#__PURE__*/React.createElement(StatBlock, {
    align: "left",
    value: "3.1",
    suffix: "x",
    label: "Average new patient growth",
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      border: '1px solid rgba(126,217,87,.22)'
    }
  })))));
}
Object.assign(window, {
  Wrap,
  SecHead,
  ProblemSection,
  EngineSection,
  ProofSection
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/MidSections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteChrome.jsx
try { (() => {
/* ChiroCandy site chrome — fixed nav (frosts on scroll) and footer. */

function SiteNav({
  onCta
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const el = document.querySelector('.cc-scroll');
    const t = el || window;
    const onScroll = () => setScrolled((el ? el.scrollTop : window.scrollY) > 40);
    t.addEventListener('scroll', onScroll);
    return () => t.removeEventListener('scroll', onScroll);
  }, []);
  const links = ['System', 'Proof', 'AI', 'Founder'];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 60,
      transition: 'background .35s, border-color .35s',
      borderBottom: '1px solid ' + (scrolled ? 'var(--cc-line)' : 'transparent'),
      background: scrolled ? 'rgba(4,16,31,.72)' : 'transparent',
      backdropFilter: scrolled ? 'blur(18px)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--cc-content-max)',
      margin: '0 auto',
      padding: '0 28px',
      height: 78,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-white.png",
    alt: "ChiroCandy",
    style: {
      height: 34,
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '2.2rem',
      fontSize: '.92rem',
      color: 'var(--cc-muted)'
    },
    className: "cc-navlinks"
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      color: 'inherit',
      textDecoration: 'none'
    },
    onMouseEnter: e => e.currentTarget.style.color = '#fff',
    onMouseLeave: e => e.currentTarget.style.color = 'var(--cc-muted)'
  }, l))), /*#__PURE__*/React.createElement(Button, {
    variant: "green",
    size: "sm",
    onClick: onCta
  }, "Book a Strategy Call")));
}
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--cc-line)',
      padding: '2.6rem 0',
      color: 'var(--cc-muted-2)',
      fontSize: '.85rem'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--cc-content-max)',
      margin: '0 auto',
      padding: '0 28px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: '1rem',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-white.png",
    alt: "ChiroCandy",
    style: {
      height: 26,
      opacity: .9
    }
  }), /*#__PURE__*/React.createElement("span", null, "\xA9 2026 ChiroCandy Marketing. Chiropractic growth since 2015.")));
}
Object.assign(window, {
  SiteNav,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteChrome.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.CredPill = __ds_scope.CredPill;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.IconChip = __ds_scope.IconChip;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.TestimonialCard = __ds_scope.TestimonialCard;

__ds_ns.Marquee = __ds_scope.Marquee;

})();
